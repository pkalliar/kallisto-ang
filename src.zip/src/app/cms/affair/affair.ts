export class Affair {
    id: string;
    code: string;
    display_name: string;
    enabled: boolean;
}
