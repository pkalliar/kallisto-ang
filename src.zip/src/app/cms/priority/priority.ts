export class Priority {
    priority: number;
    display_name: string;
  }
