export class Folder {
    id: string;
    code: string;
    display_name: string;
    enabled: boolean;
}
