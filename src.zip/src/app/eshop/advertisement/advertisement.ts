export class Advertisement {
    id: string;
    name: string;
    lastname: string;
    mobile: string;
}
