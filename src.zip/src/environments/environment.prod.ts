export const environment = {
  production: true,
  apiurl : 'https://kallisto-backend.herokuapp.com',
   firebase: {
    apiKey: 'AIzaSyBJ0SwPMbbakEGHG1YV1xKb9q_gjxpVkog',
    authDomain: 'pankal-e7786.firebaseapp.com',
    databaseURL: 'https://pankal-e7786.firebaseio.com',
    projectId: 'pankal-e7786',
    storageBucket: 'pankal-e7786.appspot.com',
    messagingSenderId: '138882110784'
   }
};
